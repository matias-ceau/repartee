"""
API clients for different AI models.
"""