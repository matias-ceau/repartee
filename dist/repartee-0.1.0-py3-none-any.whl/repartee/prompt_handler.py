"""
Handles the creation and management of prompts.
"""
