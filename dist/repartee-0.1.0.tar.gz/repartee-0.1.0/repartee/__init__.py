"""
Repartee - A CLI tool for interacting with multiple AI APIs.
"""